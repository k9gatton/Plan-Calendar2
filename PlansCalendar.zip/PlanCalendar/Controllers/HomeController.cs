﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.Mvc;

using PlanCalendar.Models;

namespace PlanCalendar.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        private PlanCalendarContext4 _db = new PlanCalendarContext4();
        public ActionResult Index()
        {
            ViewBag.CurrentEvent = new EventInfo()
            {
                BackgroundColors = new List<SelectListItem>
                {
                    new SelectListItem { Text = "Orange",
                    Value = "#cc5522"},
                    new SelectListItem {
                          Text = "Green",
                          Value = "#44cc11"
                    }
                }
            };
            CalendarInfo calInfo = new CalendarInfo();
            calInfo.StartDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            calInfo.FirstWeek = calInfo.StartDate;
            while (calInfo.FirstWeek.DayOfWeek != DayOfWeek.Sunday)
            {
                calInfo.FirstWeek = calInfo.FirstWeek.AddDays(-1);
            }
            calInfo.LastWeek = calInfo.StartDate.AddMonths(1);
           
            return View(calInfo);
        }

        public ActionResult Previous(string calInfo)
        {
            DateTime start = Convert.ToDateTime(calInfo);
            CalendarInfo caInfo = new CalendarInfo();

            caInfo.StartDate = new DateTime(start.Year, start.Month, 1);
            caInfo.FirstWeek = caInfo.StartDate;

            while (caInfo.FirstWeek.DayOfWeek != DayOfWeek.Sunday)
            {
                caInfo.FirstWeek = caInfo.FirstWeek.AddDays(-1);
            }

            caInfo.LastWeek = caInfo.StartDate.AddMonths(1);
            return View(caInfo);
        }
        public ActionResult Next(string calInfo)
        {
            DateTime start = Convert.ToDateTime(calInfo);
            CalendarInfo caInfo = new CalendarInfo();
            ViewBag.CurrentEvent = new EventInfo()
            {
                BackgroundColors = new List<SelectListItem>
                {
                    new SelectListItem { Text = "Orange",
                    Value = "#cc5522"},
                    new SelectListItem {
                          Text = "Green",
                          Value = "#44cc11"
                    }
                }
            };
            caInfo.StartDate = new DateTime(start.Year, start.Month, 1);
            caInfo.FirstWeek = caInfo.StartDate;

            while (caInfo.FirstWeek.DayOfWeek != DayOfWeek.Sunday)
            {
                caInfo.FirstWeek = caInfo.FirstWeek.AddDays(-1);
            }

            caInfo.LastWeek = caInfo.StartDate.AddMonths(1);

            return View(caInfo);
        }

        private void FillColors(ref EventInfo ei)
        {
            var dirInfo = System.IO.Directory.GetCurrentDirectory();
            var doc = XDocument.Load(@"c:\plans_config.xml");
            var colList =
                 doc.Descendants("backgroundColors").Descendants("Color").ToList();
            if (ei.BackgroundColors == null)
            {
                ei.BackgroundColors = colList.Select(x => new SelectListItem
                {
                    Text = x.Descendants("Text").FirstOrDefault().Value.ToString(),
                    Value = x.Descendants("Value").FirstOrDefault().Value.ToString()
                }).ToList();
            }
        }

        [HttpPost]
        public ActionResult AddEvent(EventInfo ei)
        {
            var start = new DateTime(ei.StartDate.Year,
                                            ei.StartDate.Month,
                                                1);
           
            if (_db.EventInfoes.Find(ei.EventID) == null)
            {
                _db.EventInfoes.Add(ei);
                _db.SaveChanges();
            }
            return RedirectToAction("Next", "Home", new { calInfo = start.ToString("yyyy-MM-dd") });
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using PlanCalendar.Models;

namespace PlanCalendar.Models
{
    public class CalendarInfo
    {
        public DateTime StartDate { get; set; }
        public DateTime FirstWeek { get; set; }
        public DateTime LastWeek { get; set; }

        public List<EventInfo> Events { get; set; }
    }
}
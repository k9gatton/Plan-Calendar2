﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.ComponentModel.DataAnnotations;

namespace PlanCalendar.Models
{
    public class DateFormatValidatorAttribute : RegularExpressionAttribute
    {
        public DateFormatValidatorAttribute()
            : base(@"[0-1][0-9]/[0-3][0-9]/20[12][0-9]")
        {
            ErrorMessage = "Please enter date in mm/dd/yyyy format";
        }

        public override bool IsValid(object value)
        {
            return true;
        }

    }
}
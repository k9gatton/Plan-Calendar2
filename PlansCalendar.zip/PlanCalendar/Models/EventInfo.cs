﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.Mvc;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;

namespace PlanCalendar.Models
{
    public class EventInfo
    {
        //Key has yyyyMMddHHmm format.

        //public EventInfo()
        //{
            
        //}

        [Key]
        public int EventID { get; set; }

        

        [Display(Name = "Event Title:")]
        [Required(ErrorMessage = "Title is required.")]
        public string Title { get; set; }

        [Display(Name = "Event Details:")]
        [DataType(DataType.MultilineText)]
        public string Comments { get; set; }

        [Display(Name = "Start Date:")]
        [Required(ErrorMessage="Start Date Required.")]
        [DataType(DataType.Date,ErrorMessage="Invalid date format. Must be MM/dd/yyyy")]
        public DateTime StartDate { get; set; }

        [Display(Name = "Length in Days:")]
        [RegularExpression("^[0-9]*$",ErrorMessage="Regular Expression must be numeric")]
        [Required(ErrorMessage="Length is required field.")]
        [DisplayFormat(DataFormatString="^[0-9]*$",ApplyFormatInEditMode=true)]
        public int Length { get; set; }

        [Display(Name = "All Day Event:")]
        public bool IsAllDay { get; set; }

        [Display(Name = "Start Time:")]
        [DataType(DataType.Time,ErrorMessage="Invalid time format.")]
        [Required(ErrorMessage = "Start time required")]
        [DisplayFormat(DataFormatString="{0:HH:mm}",ApplyFormatInEditMode=true)]
        public DateTime Start { get; set; }


        [Display(Name = "End Time:")]
        [DataType(DataType.Time,ErrorMessage="Invalid time format.")]
        [DisplayFormat(DataFormatString="{0:HH:mm}",ApplyFormatInEditMode=true)]
        public DateTime End { get; set; }


        [Display(Name = "Background Colors:")]
        public IEnumerable<SelectListItem> BackgroundColors { get; set; }


        [HiddenInput()]
        public string Background { get; set; }
    }
}